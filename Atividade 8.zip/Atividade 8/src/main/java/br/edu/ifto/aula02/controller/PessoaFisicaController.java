package br.edu.ifto.aula02.controller;

import br.edu.ifto.aula02.model.entity.PessoaFisica;
import br.edu.ifto.aula02.repository.PessoaFisicaRepository;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Transactional
@Controller
@RequestMapping("pessoafisica")
public class PessoaFisicaController {
    @Autowired
    PessoaFisicaRepository pessoaFisicaRepository;

    @GetMapping("/listar")
    public ModelAndView listar(ModelMap model) {
        model.addAttribute("pessoafisica", pessoaFisicaRepository.pessoasFisica());
        return new ModelAndView("/pessoafisica/list");
    }

    //Pessoa fisica necessário devido utilizar no form o th:object que faz referência ao objeto esperado no controller.
    @GetMapping("/form")
    public String form(PessoaFisica pessoaFisica, ModelMap model){
        model.addAttribute("isFind", true);
        return "/pessoa/form";
    }

    @PostMapping("/save")
    public ModelAndView save(@Valid @ModelAttribute("pessoaFisica") PessoaFisica pessoaFisica, BindingResult bindingResult, Model model){
        if(bindingResult.hasErrors()){
            ModelAndView modelAndView = new ModelAndView("/pessoa/form");
            modelAndView.addObject("pessoaFisica", pessoaFisica);
            return modelAndView;
        }
        pessoaFisicaRepository.save(pessoaFisica);
        return new ModelAndView("redirect:/pessoa/listar");
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap model) {
        PessoaFisica pessoaFisica = pessoaFisicaRepository.pessoaFisica(id);
        if (pessoaFisica == null) {
            return "redirect:/pessoafisica/listar";
        }
        model.addAttribute("pessoaFisica", pessoaFisica);
        return "pessoa/form";
    }

    @PostMapping("/update")
    public ModelAndView update(@Valid PessoaFisica pessoaFisica, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            ModelAndView modelAndView = new ModelAndView("/pessoa/form");
            modelAndView.addObject("pessoaFisica", pessoaFisica);
            return modelAndView;
        }
        pessoaFisicaRepository.update(pessoaFisica);
        return new ModelAndView("redirect:/pessoa/listar");
    }

    //Estou utilizando o remove da classe pessoa. Depois posso deletar esse aqui.
//    @DeleteMapping("/remove/{id}")
//    public ModelAndView remove(@PathVariable("id") Long id){
//        pessoaFisicaRepository.remove(id);
//        return new ModelAndView("redirect:/pessoa/listar");
//    }
}