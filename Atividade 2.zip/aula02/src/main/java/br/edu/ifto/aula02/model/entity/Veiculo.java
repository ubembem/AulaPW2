package br.edu.ifto.aula02.model.entity;

import jakarta.persistence.*;

@Entity
@Table
public class Veiculo {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;
    private String marca;
    private String modelo;
    private double preco;
    private int ano_fabricacao;

    public Veiculo() {}
    public Veiculo(String marca, String modelo, double preco, int ano_fabricacao) {
        this.marca = marca;
        this.modelo = modelo;
        this.preco = preco;
        this.ano_fabricacao = ano_fabricacao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getAnoFabricacao() {
        return ano_fabricacao;
    }

    public void setAnoFabricacao(int ano_fabricacao) {
        this.ano_fabricacao = ano_fabricacao;
    }

    @Override
    public String toString() {
        return "Veiculo{" +
                "id=" + id +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", preco=" + preco +
                ", anoFabricacao=" + ano_fabricacao +
                '}';
    }
}
