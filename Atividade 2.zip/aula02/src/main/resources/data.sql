create table pessoa
(
    id Long AUTO_INCREMENT PRIMARY KEY,
    nome varchar(80) not null
);

insert into pessoa (nome)values ('Maria');
insert into pessoa (nome)values ('Fagno');

create table veiculo
(
    id Long AUTO_INCREMENT PRIMARY KEY,
    marca varchar(50) not null,
    modelo varchar(50) not null,
    preco double not null,
    ano_fabricacao int not null DEFAULT 0
);

insert into veiculo(marca, modelo, preco, ano_fabricacao) values('Fiat', 'Marea', 5000, 2000);
insert into veiculo(marca, modelo, preco, ano_fabricacao) values('Ford', 'Ka', 8000, 2007);
insert into veiculo(marca, modelo, preco, ano_fabricacao) values('Ford', 'Fiesta', 10000, 2011);