package br.edu.ifto.aula02.model.jdbc;

import java.sql.Connection;

public interface ConexaoJDBC {

    public Connection criarConexao();


}
