package br.edu.ifto.aula02.controller;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Transactional
@Controller
@RequestMapping("/")
public class LoginController {

    @GetMapping("login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        Model model) {
        if (error != null) {
            model.addAttribute("mensagemErro", "Usuário ou senha inválidos.");
        }
        if (logout != null) {
            model.addAttribute("mensagemSucesso", "Você saiu do sistema.");
        }
        return "login/login";
    }

    @GetMapping("cadastro")
    public String cadastro() {
        return "redirect:/usuario/form";
    }
}