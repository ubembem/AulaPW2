package br.edu.ifto.aula02.controller;

import br.edu.ifto.aula02.model.entity.*;
import br.edu.ifto.aula02.repository.PessoaRepository;
import br.edu.ifto.aula02.repository.ProdutoRepository;
import br.edu.ifto.aula02.repository.VendaRepository;
import br.edu.ifto.aula02.repository.ItemVendaRepository;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/carrinho")
@SessionAttributes("carrinho")
@Transactional
public class CarrinhoController {
    private final VendaRepository vendaRepository;
    private final ProdutoRepository produtoRepository;
    private final PessoaRepository pessoaRepository;
    private final ItemVendaRepository itemVenda ;
    private final ItemVendaRepository itemVendaRepository;

    public CarrinhoController(VendaRepository vendaRepository, ProdutoRepository produtoRepository,
                              PessoaRepository pessoaRepository, ItemVendaRepository itemVenda, ItemVendaRepository itemVendaRepository) {
        this.vendaRepository = vendaRepository;
        this.produtoRepository = produtoRepository;
        this.pessoaRepository = pessoaRepository;
        this.itemVenda = itemVenda;
        this.itemVendaRepository = itemVendaRepository;
    }

    @ModelAttribute("carrinho")
    public ArrayList<ItemCarrinho> carrinho() {
        return new ArrayList<>();
    }

    @PostMapping("/adicionar")
    public String adicionarAoCarrinho(@RequestParam Long idProduto,
                                      @RequestParam(required = false, defaultValue = "1") int quantidade,
                                      @ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho) {
        Produto produto = produtoRepository.produto(idProduto);

        Optional<ItemCarrinho> itemExistente = carrinho.stream()
                .filter(item -> item.getProduto().getId().equals(idProduto))
                .findFirst();

        if (itemExistente.isPresent()) {
            // Atualiza a quantidade do item
            itemExistente.get().setQuantidade(itemExistente.get().getQuantidade() + quantidade);
        } else {
            carrinho.add(new ItemCarrinho(produto, quantidade));
        }
        return "redirect:/produto/listar";
    }

    @PostMapping("/atualizar")
    public String atualizarCarrinho(@RequestParam Long idProduto,
                                      @RequestParam int quantidade,
                                      @ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho, Model model) {
        Produto produto = produtoRepository.produto(idProduto);

        Optional<ItemCarrinho> itemExistente = carrinho.stream()
                .filter(item -> item.getProduto().getId().equals(idProduto))
                .findFirst();

            // Atualiza a quantidade do item
            itemExistente.get().setQuantidade(quantidade);
        List<Pessoa> clientes = pessoaRepository.pessoas();
        model.addAttribute("clientes", clientes);
        return "carrinho/list";
    }

    @GetMapping("/listar")
    public String visualizarCarrinho(@ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho, Model model) {
        BigDecimal totalCompra = carrinho.stream()
                .map(item -> item.getProduto().getValor().multiply(BigDecimal.valueOf(item.getQuantidade())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        model.addAttribute("totalCompra", totalCompra);
        List<Pessoa> clientes = pessoaRepository.pessoas();
        model.addAttribute("clientes", clientes);
        return "carrinho/list";
    }

    @PostMapping("/remover")
    public String removerDoCarrinho(@RequestParam Long idProduto, @ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho) {
        carrinho.removeIf(item -> item.getProduto().getId().equals(idProduto));
        //carrinho.remove(index);
        return "redirect:/carrinho/listar";
    }

    @PostMapping("/finalizar")
    public String finalizarCompra(@RequestParam("clienteId") Long clienteId, @ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho, Model model, RedirectAttributes redirectAttributes) {
        if (carrinho.isEmpty()) {
            redirectAttributes.addFlashAttribute("mensagemErro", "O carrinho está vazio. Adicione itens antes de finalizar a compra.");
            return "redirect:/carrinho/listar";
        }
        Venda venda = new Venda();
        venda.setDataVenda(LocalDateTime.now());

        // salvar em o cliente genérico até fazer a opção de login
        Pessoa clienteAtual = pessoaRepository.pessoa(clienteId);
        for (ItemCarrinho item : carrinho) {
            ItemVenda itemVenda = new ItemVenda();
            itemVenda.setProduto(item.getProduto());
            itemVenda.setQuantidade(item.getQuantidade());
            itemVenda.setVenda(venda);
            itemVendaRepository.save(itemVenda);

            venda.getItensVenda().add(itemVenda);
        }
        venda.setPessoa(clienteAtual);
        vendaRepository.save(venda);
        carrinho.clear();
        return "redirect:/venda/listar";
    }
}
