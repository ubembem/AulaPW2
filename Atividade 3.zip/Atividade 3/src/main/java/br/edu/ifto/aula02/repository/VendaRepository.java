package br.edu.ifto.aula02.repository;

import br.edu.ifto.aula02.model.entity.ItemVenda;
import br.edu.ifto.aula02.model.entity.Venda;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class VendaRepository {

    @PersistenceContext
    private EntityManager em;

    public void save(Venda venda){
        em.persist(venda);
    }

    public Venda venda(Long id){
        return em.find(Venda.class, id);
    }

    public List<Venda> vendas(){
        Query query = em.createQuery("from Venda");
        System.out.println("Passei no list do repository" + query.getResultList());
        return query.getResultList();
    }

    public List<ItemVenda> detalhesVendas(Long id) {
        try {
            TypedQuery<ItemVenda> query = em.createQuery("SELECT iv FROM ItemVenda iv WHERE iv.venda.id = :id", ItemVenda.class);
            query.setParameter("id", id);
            return query.getResultList();
        } catch (Exception e) {
            // Logar a exceção e lançar uma exceção personalizada ou uma exceção mais específica
            // Por exemplo:
            System.out.println("Erro ao buscar detalhes da venda"+ e);
            throw new RuntimeException("Erro ao buscar detalhes da venda", e);
        }
    }
    public void remove(Long id){
        Venda p = em.find(Venda.class, id);
        System.out.println("Venda: " + p.toString() + " removido");
        em.remove(p);
    }

    public void update(Venda venda){
        em.merge(venda);
    }
}