package br.edu.ifto.aula02.model.entity;

import jakarta.persistence.*;

@Entity
@DiscriminatorValue("J")
public class PessoaJuridica extends Pessoa{
    //@Column(name="nome") //Usei isso para funcionar antes de achar uma forma do thymelef saber de qual classe concreta
    // se tratava, para não retornar nulo o campo e causar erro. Dai evitava de usar dois formulários.
    private String razaoSocial;
    //@Column(name="cpfOuCnpj") //idem.O benefício é que fica so um campo tanto para pessoa juridica como fisica, evitando deixar espaços vazios no banco.
    private String cnpj;

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNome( ){return razaoSocial;}

    public String getCpf( ){return cnpj;}

    public String getTipo( ){return "J";}
}
