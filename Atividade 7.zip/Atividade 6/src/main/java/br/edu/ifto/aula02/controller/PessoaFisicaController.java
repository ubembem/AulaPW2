package br.edu.ifto.aula02.controller;

import br.edu.ifto.aula02.model.entity.PessoaFisica;
import br.edu.ifto.aula02.repository.PessoaFisicaRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Transactional
@Controller
@RequestMapping("pessoafisica")
public class PessoaFisicaController {
    @Autowired
    PessoaFisicaRepository pessoaFisicaRepository;

    @GetMapping("/listar")
    public ModelAndView listar(ModelMap model) {
        model.addAttribute("pessoafisica", pessoaFisicaRepository.pessoasFisica());
        return new ModelAndView("/pessoafisica/list");
    }

    //Pessoa fisica necessário devido utilizar no form o th:object que faz referência ao objeto esperado no controller.
    @GetMapping("/form")
    public String form(PessoaFisica pessoaFisica, ModelMap model){
        model.addAttribute("isFind", true);
        return "/pessoa/form";
    }

    @PostMapping("/save")
    public ModelAndView save(PessoaFisica pessoaFisica){
        pessoaFisicaRepository.save(pessoaFisica);
        return new ModelAndView("redirect:/pessoa/listar");
    }

    //Estou utilizando o remove da classe pessoa. Depois posso deletar esse aqui.
    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id){
        pessoaFisicaRepository.remove(id);
        return new ModelAndView("redirect:/pessoa/listar");
    }

    /**
     * @param id
     * @return
     * @PathVariable é utilizado quando o valor da variável é passada diretamente na URL
     */
    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        model.addAttribute("pessoaFisica", pessoaFisicaRepository.pessoaFisica(id));
        return new ModelAndView("/fragments/form", model);
    }

    @PostMapping("/update")
    public ModelAndView update(PessoaFisica pessoaFisica) {
        pessoaFisicaRepository.update(pessoaFisica);
        return new ModelAndView("redirect:/pessoa/listar");
    }

//    @GetMapping("/consulta{nome}")
//    public String consultarPessoaFisica(@RequestParam("nome") String nome, Model model) {
//        List<PessoaFisica> pf = pessoaFisicaRepository.buscaPorNome(nome);
//        model.addAttribute("pessoasfisica", pf.listIterator());
//        model.addAttribute("nomeBusca", nome); // Para exibir o termo de busca na página
//        return "pessoafisica/list";
//    }
}