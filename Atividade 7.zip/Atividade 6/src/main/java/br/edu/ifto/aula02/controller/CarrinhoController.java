package br.edu.ifto.aula02.controller;

import br.edu.ifto.aula02.model.entity.*;
import br.edu.ifto.aula02.repository.PessoaRepository;
import br.edu.ifto.aula02.repository.ProdutoRepository;
import br.edu.ifto.aula02.repository.VendaRepository;
import br.edu.ifto.aula02.repository.ItemVendaRepository;
import jakarta.transaction.Transactional;
import org.hibernate.mapping.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Optional;

@Controller
@RequestMapping("/carrinho")
@SessionAttributes("carrinho")
@Transactional
public class CarrinhoController {
    private final VendaRepository vendaRepository;
    private final ProdutoRepository produtoRepository;
    private final PessoaRepository pessoaRepository;
    private final ItemVendaRepository itemVenda ;
    private final ItemVendaRepository itemVendaRepository;

    public CarrinhoController(VendaRepository vendaRepository, ProdutoRepository produtoRepository,
                              PessoaRepository pessoaRepository, ItemVendaRepository itemVenda, ItemVendaRepository itemVendaRepository) {
        this.vendaRepository = vendaRepository;
        this.produtoRepository = produtoRepository;
        this.pessoaRepository = pessoaRepository;
        this.itemVenda = itemVenda;
        this.itemVendaRepository = itemVendaRepository;
    }

    @ModelAttribute("carrinho")
    public ArrayList<ItemCarrinho> carrinho() {
        return new ArrayList<>();
    }

    @PostMapping("/adicionar")
    public String adicionarAoCarrinho(@RequestParam Long idProduto,
                                      @RequestParam(required = false, defaultValue = "1") int quantidade,
                                      @ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho) {
        Produto produto = produtoRepository.produto(idProduto);

        Optional<ItemCarrinho> itemExistente = carrinho.stream()
                .filter(item -> item.getProduto().getId().equals(idProduto))
                .findFirst();

        if (itemExistente.isPresent()) {
            // Atualiza a quantidade do item
            itemExistente.get().setQuantidade(itemExistente.get().getQuantidade() + quantidade);
        } else {
            carrinho.add(new ItemCarrinho(produto, quantidade));
        }
        return "redirect:/produto/listar";
    }

    @GetMapping("/listar")
    public String visualizarCarrinho(@ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho, Model model) {
        BigDecimal totalCompra = carrinho.stream()
                .map(item -> item.getProduto().getValor().multiply(BigDecimal.valueOf(item.getQuantidade())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        model.addAttribute("totalCompra", totalCompra);
        return "carrinho/list";
    }

    @PostMapping("/remover")
    public String removerDoCarrinho(@RequestParam Long idProduto, @ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho) {
        carrinho.removeIf(item -> item.getProduto().getId().equals(idProduto));
        return "redirect:/carrinho/listar";
    }

    @PostMapping("/comprarAgora")
    public String comprarAgora(@RequestParam Long idProduto,
                               @RequestParam int quantidade,
                               @ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho) {
        Produto produto = produtoRepository.produto(idProduto);
        carrinho.add(new ItemCarrinho(produto, quantidade));

        // Redireciona diretamente para a página de finalização
        return "redirect:/carrinho/listar";
    }

    @PostMapping("/finalizar")
    public String finalizarCompra(@ModelAttribute("carrinho") ArrayList<ItemCarrinho> carrinho, Model model) {
        if (carrinho.isEmpty()) {
            model.addAttribute("mensagemErro", "O carrinho está vazio. Adicione itens antes de finalizar a compra.");
            return "redirect:/carrinho/listar";
        }
        Venda venda = new Venda();
        venda.setDataVenda(LocalDateTime.now());

        // salvar em o cliente genérico até fazer a opção de login
        Pessoa clienteGenerico = pessoaRepository.pessoa(1L);
        for (ItemCarrinho item : carrinho) {
            ItemVenda itemVenda = new ItemVenda();
            itemVenda.setProduto(item.getProduto());
            itemVenda.setQuantidade(item.getQuantidade());
            itemVenda.setVenda(venda);
            itemVendaRepository.save(itemVenda);

            venda.getItensVenda().add(itemVenda);
        }
        venda.setPessoa(clienteGenerico);
        vendaRepository.save(venda);
        carrinho.clear();
        return "redirect:/venda/listar";
    }
}
